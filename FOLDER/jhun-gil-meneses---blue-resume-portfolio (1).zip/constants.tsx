import React from 'react';
import { Project, EducationItem, ExperienceItem } from './types';

export const PERSONAL_INFO = {
  name: "Meneses, Jhun Gil S.",
  address: "#369 PNR Site Mayombo District, Dagupan City, Pangasinan",
  birthdate: "June 14, 2003",
  email: "jhun.gil.meneses@gmail.com",
  github: "https://github.com/jhungilmeneses",
  phone: "09542838164",
  profileImage: "https://i.imgur.com/3AsDh5Z.png", // Updated to the new provided link
  tagline: "Computer Engineering Student & Tech Enthusiast"
};

export const EDUCATION: EducationItem[] = [
  { level: "College", school: "Universidad de Dagupan", specialization: "Bachelor of Science in Computer Engineering" },
  { level: "Senior High School", school: "Dagupan City National High School" },
  { level: "High School", school: "Dagupan City National High School" },
  { level: "Elementary", school: "Wonderland School" }
];

export const EXPERIENCES: ExperienceItem[] = [
  { title: "Freelance Developer", description: "Providing custom hardware and software solutions for various clients." },
  { title: "PC Troubleshooting", description: "Expertise in diagnosing and repairing hardware/software issues in personal computers." },
  { title: "PCB Making", description: "Design and fabrication of custom Printed Circuit Boards for specialized electronics projects." }
];

export const PROJECTS: Project[] = [
  { 
    title: "Screwed/Screwless Modular Assemblable Robotic System", 
    description: "A versatile robotic platform designed for quick assembly and modular hardware expansion.", 
    tags: ["Robotics", "Mechanical Design", "Modular"],
    image: "https://i.imgur.com/9Febkij.png"
  },
  { 
    title: "Soccer Bot", 
    description: "Automated and remote-controlled robots designed for competitive robotic soccer matches.", 
    tags: ["Competition", "Arduino", "Motor Control"],
    image: "https://i.imgur.com/QP27JAO.png"
  },
  { 
    title: "Mini Arcade", 
    description: "Portable retro gaming console built using custom hardware and emulation software.", 
    tags: ["Embedded Systems", "Gaming", "UX Design"],
    image: "https://i.imgur.com/G6ikaA0.png"
  },
  { 
    title: "Bionic Arm", 
    description: "A prosthetic arm prototype controlled by muscle signals or joystick inputs.", 
    tags: ["Biomechatronics", "Servos", "Prosthetics"] 
  },
  { 
    title: "Light Follower", 
    description: "Autonomous robot that tracks and navigates towards the strongest light source in its environment.", 
    tags: ["Sensors", "Automation", "Analog Circuits"],
    image: "https://i.imgur.com/0YgS3zO.png"
  },
  { 
    title: "DigiCat (Virtual Pet Companion)", 
    description: "An interactive digital companion project with OLED display and sensory interaction.", 
    tags: ["Virtual Pet", "Software", "Hardware"] 
  }
];