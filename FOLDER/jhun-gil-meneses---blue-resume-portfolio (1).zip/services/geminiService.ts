
import { GoogleGenAI } from "@google/genai";
import { PERSONAL_INFO, EDUCATION, EXPERIENCES, PROJECTS } from "../constants";

export const getGeminiAssistant = async (userMessage: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `
    You are an AI assistant for the portfolio website of ${PERSONAL_INFO.name}.
    Respond to visitors politely and professionally.
    
    Context about Jhun:
    - Address: ${PERSONAL_INFO.address}
    - Education: ${EDUCATION.map(e => `${e.level} at ${e.school}`).join(', ')}
    - Skills & Experience: ${EXPERIENCES.map(e => e.title).join(', ')}
    - Major Projects: ${PROJECTS.map(p => p.title).join(', ')}
    
    If someone asks for contact info, provide the email: ${PERSONAL_INFO.email}.
    Keep answers concise and related to Jhun's career and projects.
    Use a friendly, technical, and professional tone.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });
    return response.text || "I'm sorry, I couldn't process that request right now.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "The AI assistant is currently offline. Please try again later.";
  }
};
