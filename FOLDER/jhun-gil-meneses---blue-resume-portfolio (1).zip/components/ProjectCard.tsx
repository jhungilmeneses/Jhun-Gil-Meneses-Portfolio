
import React from 'react';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  return (
    <div className="glass-card flex flex-col h-full rounded-2xl hover:border-blue-500 transition-all duration-300 group cursor-default overflow-hidden">
      {project.image && (
        <div className="w-full h-48 overflow-hidden border-b border-white/5">
          <img 
            src={project.image} 
            alt={project.title} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
        </div>
      )}
      <div className="p-6 flex flex-col flex-1">
        <div className="mb-4 text-blue-500 opacity-80 group-hover:scale-110 transition-transform origin-left">
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m8 2 1.88 1.88"/><path d="M14 19l4.88 4.88"/><path d="M8 22l4.88-4.88"/><path d="M14 5l1.88-1.88"/><path d="M4 10h16"/><path d="M10 4v16"/><path d="M14 4v16"/><path d="M4 14h16"/></svg>
        </div>
        <h3 className="text-xl font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">
          {project.title}
        </h3>
        <p className="text-slate-400 text-sm mb-4 leading-relaxed flex-1">
          {project.description}
        </p>
        <div className="flex flex-wrap gap-2">
          {project.tags.map(tag => (
            <span key={tag} className="text-[10px] uppercase font-bold tracking-tighter px-2 py-1 bg-blue-900/40 text-blue-300 rounded border border-blue-800">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
