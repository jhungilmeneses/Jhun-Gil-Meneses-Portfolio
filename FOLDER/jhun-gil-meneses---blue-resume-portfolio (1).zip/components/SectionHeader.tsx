
import React from 'react';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({ title, subtitle }) => {
  return (
    <div className="mb-12">
      <h2 className="text-3xl md:text-4xl font-bold text-blue-400 mb-2 uppercase tracking-widest text-glow">
        {title}
      </h2>
      <div className="h-1 w-20 bg-blue-600 rounded-full mb-4"></div>
      {subtitle && <p className="text-slate-400 max-w-2xl">{subtitle}</p>}
    </div>
  );
};
