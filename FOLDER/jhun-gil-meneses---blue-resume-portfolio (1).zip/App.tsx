
import React from 'react';
import { PERSONAL_INFO, EXPERIENCES, EDUCATION, PROJECTS } from './constants';
import { SectionHeader } from './components/SectionHeader';
import { ProjectCard } from './components/ProjectCard';
import { AIAssistant } from './components/AIAssistant';

const App: React.FC = () => {
  return (
    <div className="min-h-screen relative selection:bg-blue-500/30">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-900/20 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-700/10 blur-[120px] rounded-full"></div>
      </div>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="text-xl font-extrabold tracking-tighter text-blue-500 uppercase">
            J<span className="text-white">G</span>M
          </div>
          <div className="hidden md:flex gap-8 text-sm font-medium uppercase tracking-widest text-slate-400">
            <a href="#about" className="hover:text-blue-400 transition-colors">About</a>
            <a href="#projects" className="hover:text-blue-400 transition-colors">Projects</a>
            <a href="#education" className="hover:text-blue-400 transition-colors">Education</a>
            <a href="#contact" className="hover:text-blue-400 transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="about" className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-block px-4 py-1 rounded-full bg-blue-900/30 text-blue-400 text-xs font-bold tracking-widest border border-blue-800 uppercase">
              Available for opportunities
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-white leading-tight">
              {PERSONAL_INFO.name.split(',')[0]}<br/>
              <span className="text-blue-500">{PERSONAL_INFO.name.split(',')[1]}</span>
            </h1>
            <p className="text-xl text-slate-400 max-w-lg leading-relaxed">
              {PERSONAL_INFO.tagline}. Specialized in robotics, embedded systems, and hardware troubleshooting.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <a href="#contact" className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold transition-all shadow-lg shadow-blue-600/20">
                Let's Talk
              </a>
              <a href="#projects" className="px-8 py-3 border border-slate-700 hover:border-blue-500 text-white rounded-lg font-bold transition-all">
                View Work
              </a>
              <a href={PERSONAL_INFO.github} target="_blank" rel="noopener noreferrer" className="px-8 py-3 border border-slate-700 hover:border-blue-500 text-white rounded-lg font-bold transition-all flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/></svg>
                GitHub
              </a>
            </div>
          </div>
          <div className="relative flex justify-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-3xl overflow-hidden border-4 border-blue-600/20 shadow-2xl">
              <img src={PERSONAL_INFO.profileImage} alt={PERSONAL_INFO.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent"></div>
            </div>
            <div className="absolute -bottom-4 -right-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-xl hidden md:block">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/></svg>
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Born</p>
                  <p className="text-sm font-bold text-white">{PERSONAL_INFO.birthdate}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-20 px-6 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <SectionHeader title="Expertise" subtitle="Hands-on experience in electronics, hardware diagnosis, and independent contracting." />
          <div className="grid md:grid-cols-3 gap-6">
            {EXPERIENCES.map((exp, idx) => (
              <div key={idx} className="glass-card p-8 rounded-2xl border-white/5 hover:border-blue-600/50 transition-colors">
                <h3 className="text-2xl font-bold text-white mb-4">{exp.title}</h3>
                <p className="text-slate-400 leading-relaxed">{exp.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <SectionHeader title="Projects" subtitle="A showcase of innovative robotics and embedded systems projects developed during my studies." />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {PROJECTS.map((project, idx) => (
              <ProjectCard key={idx} project={project} />
            ))}
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 px-6 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <SectionHeader title="Education" subtitle="My academic journey and specialized training in Computer Engineering." />
          <div className="space-y-4">
            {EDUCATION.map((edu, idx) => (
              <div key={idx} className="relative pl-8 pb-8 border-l-2 border-blue-800 last:pb-0">
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]"></div>
                <div className="bg-slate-900/50 border border-white/5 p-6 rounded-2xl hover:bg-slate-800/50 transition-colors">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-2">
                    <h3 className="text-xl font-bold text-white">{edu.level}</h3>
                    <span className="text-xs font-bold text-blue-400 tracking-widest uppercase">{edu.school}</span>
                  </div>
                  {edu.specialization && (
                    <p className="text-slate-400 font-medium italic">{edu.specialization}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="glass-card bg-blue-900/20 p-8 md:p-16 rounded-[40px] border-blue-500/20 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 blur-3xl rounded-full"></div>
            <div className="relative z-10 grid md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-4xl font-black text-white mb-6 uppercase tracking-tight">Let's Connect</h2>
                <p className="text-slate-400 mb-8 max-w-sm">Interested in collaboration or hardware troubleshooting? Feel free to reach out via email or github.</p>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 text-slate-300">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-blue-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                    </div>
                    <span>{PERSONAL_INFO.email}</span>
                  </div>
                  <div className="flex items-center gap-4 text-slate-300">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-blue-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                    </div>
                    <span>{PERSONAL_INFO.phone}</span>
                  </div>
                  <div className="flex items-center gap-4 text-slate-300">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-blue-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/></svg>
                    </div>
                    <a href={PERSONAL_INFO.github} target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">github.com/jhungilmeneses</a>
                  </div>
                  <div className="flex items-center gap-4 text-slate-300">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-blue-400">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <span>{PERSONAL_INFO.address}</span>
                  </div>
                </div>
              </div>
              <div className="bg-slate-950/50 p-6 md:p-8 rounded-3xl border border-white/5">
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Message</label>
                    <textarea className="w-full bg-slate-900 border border-slate-800 rounded-xl p-4 text-white focus:outline-none focus:ring-1 focus:ring-blue-500 min-h-[120px]" placeholder="Hi Jhun, I'd like to talk about..."></textarea>
                  </div>
                  <button className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-blue-900/40">
                    Send Message
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/5 text-center">
        <div className="max-w-7xl mx-auto">
          <div className="text-xl font-extrabold tracking-tighter text-blue-500 uppercase mb-4">
            J<span className="text-white">G</span>M
          </div>
          <p className="text-slate-500 text-sm">
            &copy; {new Date().getFullYear()} Jhun Gil Meneses. Built with React, Tailwind & AI.
          </p>
        </div>
      </footer>

      {/* AI Assistant FAB */}
      <AIAssistant />
    </div>
  );
};

export default App;
