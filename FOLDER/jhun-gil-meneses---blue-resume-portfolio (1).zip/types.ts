
export interface Project {
  title: string;
  description: string;
  tags: string[];
  image?: string;
}

export interface EducationItem {
  level: string;
  school: string;
  specialization?: string;
}

export interface ExperienceItem {
  title: string;
  description: string;
}
